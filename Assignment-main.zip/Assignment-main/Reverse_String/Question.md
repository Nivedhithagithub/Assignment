## Problem Statement

Write a Java program to reverse a given string

### Condition

The reverse string should be printed in lowercase only.

## Input

    WelCome

## Output

    emoclew
