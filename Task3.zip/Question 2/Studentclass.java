package com.example.model;

public class Student {
    private String name;
    private int id;

    // Constructor, getters, and setters
}
